import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'multistepReactiveForm';

  //registerForm:FormGroup;
  constructor(){}//private Fb:FormBuilder){}
  
  steps:number=1;

  ngOnInit(): void {

  }



  submitData(){
    this.steps=this.steps+1;
  }

  goback(){
    this.steps=this.steps-1;
  }

  next(){
    this.steps=this.steps+1;

  }

}
